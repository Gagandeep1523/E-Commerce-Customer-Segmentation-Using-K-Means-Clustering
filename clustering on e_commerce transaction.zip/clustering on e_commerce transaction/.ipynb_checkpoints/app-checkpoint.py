import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

# -----------------------------
# Load Aggregated Data
# -----------------------------
st.title("📊 E-Commerce Customer Segmentation (K-Means)")

user_df = pd.read_csv("clustered_customers.csv")  
st.subheader("Sample Data")


# -----------------------------
# Scale features
# -----------------------------
features = ['Age','Total_Purchase','Avg_Purchase','Num_Transactions']
X = user_df[features]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -----------------------------
# K-Means Clustering
# -----------------------------
kmeans = KMeans(n_clusters=2, random_state=42)
user_df['Cluster'] = kmeans.fit_predict(X_scaled)

st.subheader("Cluster Counts")
st.bar_chart(user_df['Cluster'].value_counts())

st.subheader("Cluster Summary")
st.dataframe(user_df.groupby('Cluster')[features].mean())

# -----------------------------
# Boxplots
# -----------------------------
st.subheader("Feature Distribution by Cluster")
for col in features[1:]:  # Exclude Age
    fig, ax = plt.subplots()
    sns.boxplot(x='Cluster', y=col, data=user_df, ax=ax)
    st.pyplot(fig)

# -----------------------------
# PCA 2D Visualization
# -----------------------------
st.subheader("PCA 2D Cluster Visualization")
pca = PCA(n_components=2)
pca_result = pca.fit_transform(X_scaled)
user_df['PCA1'] = pca_result[:,0]
user_df['PCA2'] = pca_result[:,1]

fig, ax = plt.subplots()
sns.scatterplot(x='PCA1', y='PCA2', hue='Cluster', palette='Set2', data=user_df, ax=ax)
st.pyplot(fig)

# -----------------------------
# Predict Cluster for New Customer
# -----------------------------
st.subheader("Predict Cluster for New Customer")
st.write("Enter customer details to see which cluster they belong to:")

new_age = st.number_input("Age", min_value=0, max_value=120, value=30)
new_total = st.number_input("Total Purchase", min_value=0, value=1000)
new_avg = st.number_input("Average Purchase", min_value=0, value=100)
new_num = st.number_input("Number of Transactions", min_value=0, value=5)

if st.button("Predict Cluster"):
    new_customer = pd.DataFrame([[new_age, new_total, new_avg, new_num]], columns=features)
    new_scaled = scaler.transform(new_customer)
    cluster_pred = kmeans.predict(new_scaled)[0]
    
    if cluster_pred == 1:
        st.success(f"✅ New customer belongs to **High-Value Customer Cluster (1)**")
    else:
        st.info(f"ℹ️ New customer belongs to **Moderate-Value Customer Cluster (0)**")

